#!/usr/bin/env python3
"""
CS 4200 - Final Project
Cache Design Exploration Simulator: A comparison of different cache organizations

Simulates:
- direct mapped
- 2-way
- 4-way

Input:
- hex_inst.txt (for testing, I would add a number so it would be like hex_inst1.txt and so on)

Outputs:
- *_cache.log
- *_stats.log

*it makes a cache and stats log for direct mapped, 2-way, and 4-way

Evaluation Metrics:
- cache hit rate
- cache miss rate
- writebacks

Concepts:
- cache associativity
- conflict misses
- performance tradeoffs
"""

CACHE_SIZE_BYTES = 1024
BLOCK_BYTES = 16

# Cache Construction

def cache_make(assoc):
    num_blocks = CACHE_SIZE_BYTES // BLOCK_BYTES
    num_sets = num_blocks // assoc

    cache = []
    for _ in range(num_sets):
        ways = []
        for _ in range(assoc):
            ways.append({
                "valid": 0,
                "dirty": 0,
                "tag": 0,
                "lru": 0,
            })
        cache.append(ways)

    return cache, num_sets

# Address decoding

def addr_parts(addr, num_sets):
    block_addr = addr // BLOCK_BYTES
    set_index = block_addr % num_sets
    tag = block_addr // num_sets
    return tag, set_index

# LRU

def update_lru(cache, set_index, used_way):
    ways = cache[set_index]
    max_lru = max(w["lru"] for w in ways)
    ways[used_way]["lru"] = max_lru + 1


def choose_victim(cache, set_index):
    ways = cache[set_index]

    # empty line first
    for i in range(len(ways)):
        if ways[i]["valid"] == 0:
            return i

    # LRU eviction
    min_lru = ways[0]["lru"]
    victim = 0

    for i in range(1, len(ways)):
        if ways[i]["lru"] < min_lru:
            min_lru = ways[i]["lru"]
            victim = i

    return victim

# Cache Access

def cache_access(cache, addr, num_sets, log, stats):
    tag, set_index = addr_parts(addr, num_sets)
    ways = cache[set_index]

    # HIT
    for i in range(len(ways)):
        if ways[i]["valid"] and ways[i]["tag"] == tag:
            stats["hits"] += 1
            update_lru(cache, set_index, i)
            log.append(f"HIT  | addr=0x{addr:08X} set={set_index} way={i} tag=0x{tag:X}")
            return

    # MISS
    stats["misses"] += 1
    victim = choose_victim(cache, set_index)

    line = ways[victim]

    # writeback if needed
    if line["valid"] and line["dirty"]:
        stats["writebacks"] += 1
        log.append(f"WB   | set={set_index} way={victim} old_tag=0x{line['tag']:X}")

    # eviction only if valid
    if line["valid"]:
        log.append(f"EVICT| set={set_index} way={victim} tag=0x{line['tag']:X}")

    # fill new block
    line["valid"] = 1
    line["tag"] = tag
    line["dirty"] = 0

    update_lru(cache, set_index, victim)

    log.append(f"MISS | addr=0x{addr:08X} set={set_index} way={victim} tag=0x{tag:X}")

# Input Loader

def load_accesses(path):
    accesses = []

    with open(path, "r") as f:
        for line in f:
            s = line.strip()
            if not s or s.startswith("#"):
                continue

            if s.lower().startswith("0x"):
                s = s[2:]

            accesses.append(int(s, 16))

    return accesses 

# Output Helpers

def write_lines(path, lines):
    with open(path, "w") as f:
        for l in lines:
            f.write(l + "\n")


def write_stats(path, stats, assoc):
    total = stats["hits"] + stats["misses"]
    hit_rate = stats["hits"] / total if total else 0

    lines = [
        f"Associativity: {assoc}",
        f"Total accesses: {total}",
        f"Hits: {stats['hits']}",
        f"Misses: {stats['misses']}",
        f"Hit rate: {hit_rate:.4f}",
        f"Writebacks: {stats['writebacks']}",
    ]

    write_lines(path, lines)

# Simulation Runner

def run_sim(name, assoc, accesses):
    cache, num_sets = cache_make(assoc)

    log = []
    stats = {
        "hits": 0,
        "misses": 0,
        "writebacks": 0,
    }

    for addr in accesses:
        cache_access(cache, addr, num_sets, log, stats)

    write_lines(f"{name}_cache.log", log)
    write_stats(f"{name}_stats.log", stats, assoc)

    print(f"{name} DONE")

# Main

def main():
    test_files = [
        "hex_inst1.txt",
        "hex_inst2.txt",
        "hex_inst3.txt"
    ]

    for file in test_files:
        print("\n==============================")
        print("Running:", file)
        print("==============================")

        accesses = load_accesses(file)

        print("ACCESS COUNT =", len(accesses))

        run_sim(file.replace(".txt", "_direct"), 1, accesses)
        run_sim(file.replace(".txt", "_2way"), 2, accesses)
        run_sim(file.replace(".txt", "_4way"), 4, accesses)

    print("\nALL TESTS DONE")

if __name__ == "__main__":
    main()